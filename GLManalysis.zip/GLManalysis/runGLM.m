runGLM_split('SO','detect',1); clear all
runGLM_split('SO','detect',2); clear all
runGLM_split('SO','detect',3); clear all

runGLM_split('SO','memory',1); clear all
runGLM_split('SO','memory',2); clear all;
runGLM_split('SO','memory',3); clear all;

runGLM_split('DS','memory',1); clear all
runGLM_split('DS','memory',2); clear all;
runGLM_split('DS','memory',3); clear all;

runGLM_split('RS','detect',1); clear all
runGLM_split('RS','detect',2); clear all
runGLM_split('RS','detect',3); clear all

runGLM_split('RS','memory',1); clear all
runGLM_split('RS','memory',2); clear all;
runGLM_split('RS','memory',3); clear all;

runGLM_split('LM','detect',1); clear all
runGLM_split('LM','detect',2); clear all
runGLM_split('LM','detect',3); clear all

runGLM_split('LM','memory',1); clear all
runGLM_split('LM','memory',2); clear all;
runGLM_split('LM','memory',3); clear all;


break
runGLM_split('JG','detect',1); clear all
runGLM_split('JG','detect',2); clear all
runGLM_split('JG','detect',3); clear all

runGLM_split('JG','memory',1); clear all
runGLM_split('JG','memory',2); clear all;
runGLM_split('JG','memory',3); clear all;

runGLM_split('DS','detect',1); clear all
runGLM_split('DS','detect',2); clear all
runGLM_split('DS','detect',3); clear all


% runGLMbyDM_FDR('allSubj','detect',5,3,1); clear all
% runGLMbyDM_FDR('allSubj','memory',5,3,1); clear all

% runGLMbyDM_FDR('allSubj','detect',5,3,0); clear all
% runGLMbyDM_FDR('allSubj','memory',5,3,0); clear all
