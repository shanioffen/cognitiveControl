 estimateBetas('DS','detect',1,1); close all
 estimateBetas('DS','detect',1,2); close all;
 estimateBetas('DS','detect',1,3); close all;
 
 estimateBetas('DS','memory',1,1); close all
 estimateBetas('DS','memory',1,2); close all
estimateBetas('DS','memory',1,2); close all

 estimateBetas('RS','detect',1,1); close all
 estimateBetas('RS','detect',1,2); close all
estimateBetas('RS','detect',1,3); close all

 estimateBetas('RS','memory',1,1); close all
 estimateBetas('RS','memory',1,2); close all
 estimateBetas('RS','memory',1,3); close all

 estimateBetas('LM','detect',1,1); close all
 estimateBetas('LM','detect',1,2); close all
estimateBetas('LM','detect',1,3); close all

 estimateBetas('LM','memory',1,1); close all
 estimateBetas('LM','memory',1,2); close all
 estimateBetas('LM','memory',1,3); close all

 estimateBetas('SO','detect',1,1); close all
 estimateBetas('SO','detect',1,2); close all
estimateBetas('SO','detect',1,3); close all

 estimateBetas('SO','memory',1,1); close all
 estimateBetas('SO','memory',1,2); close all
 estimateBetas('SO','memory',1,3); close all

 estimateBetas('JG','detect',1,1); close all
 estimateBetas('JG','detect',1,2); close all
 estimateBetas('JG','detect',1,3); close all

 estimateBetas('JG','memory',1,1); close all
 estimateBetas('JG','memory',1,2); close all
 estimateBetas('JG','memory',1,3); close all

 
