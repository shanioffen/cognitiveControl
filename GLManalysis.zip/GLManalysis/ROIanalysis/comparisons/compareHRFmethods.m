>> compareDurations('JG','detect',2)
>> compareDurations('JG','detect',2,1)
>> compareDur_estHRF('JG','detect',2) 
