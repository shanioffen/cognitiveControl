if(1)
mkDM_s2minus_master('JG','memory');
mkDM_s2minus_master('JG','detect');
%mkDM_s2minus_mast�er('JG','vertical');
%mkDM_s2minus_master('JG','memDetect');

mkDM_s2minus_master('RS','memory');
mkDM_s2minus_master('RS','detect');
%mkDM_s2minus_master('RS','vertical');
%mkDM_s2minus_master('RS','memDetect');

mkDM_s2minus_master('LM','memory');
mkDM_s2minus_master('LM','detect');
%mkDM_s2minus_master('LM','vertical');
%mkDM_s2minus_master('LM','memDetect');

mkDM_s2minus_master('DS','memory');
mkDM_s2minus_master('DS','detect');
%mkDM_s2minus_master('DS','vertical');
%mkDM_s2minus_master('DS','memDetect');

mkDM_s2minus_master('SO','memory');
mkDM_s2minus_master('SO','detect');
%mkDM_s2minus_master('SO','vertical');
%mkDM_s2minus_master('SO','memDetect');
end

if(0)
mkDM_correct_master('JG','memory');
mkDM_correct_master('JG','detect');
%mkDM_correct_mast�er('JG','vertical');
%mkDM_correct_master('JG','memDetect');

mkDM_correct_master('RS','memory');
mkDM_correct_master('RS','detect');
%mkDM_correct_master('RS','vertical');
%mkDM_correct_master('RS','memDetect');

mkDM_correct_master('LM','memory');
mkDM_correct_master('LM','detect');
%mkDM_correct_master('LM','vertical');
%mkDM_correct_master('LM','memDetect');

mkDM_correct_master('DS','memory');
mkDM_correct_master('DS','detect');
%mkDM_correct_master('DS','vertical');
%mkDM_correct_master('DS','memDetect');

mkDM_correct_master('SO','memory');
mkDM_correct_master('SO','detect');
%mkDM_correct_master('SO','vertical');
%mkDM_correct_master('SO','memDetect');

end