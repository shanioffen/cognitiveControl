% getCorrCoef
% 2008 May 17 Shani Offen
% adapted JG's getR2 to also
% get correlation coefficients and set as field in d, so can calculate
% pvalues and get FDR threshold for showing maps
%
function d = getCorrCoefOBSOLETE(d)

% init some variables
ehdr=[];correlation = [];r2 = [];

% precalculate the normal equation (this dramatically speeds up things)
precalcmatrix = ((d.scm'*d.scm)^-1)*d.scm';
% if this don't work then do pinv
if sum(isnan(precalcmatrix(:))) == length(precalcmatrix(:))
  disp(sprintf('(getr2) Using pseudo inverse to invert convolution matrix'));
  precalcmatrix = pinv(d.scm);
end

% check roi
slices = 1:d.dim(3);slicen = length(slices);
xvals = 1:d.dim(1);xvaln = length(xvals);
yvals = 1:d.dim(2);yvaln = length(yvals);
  
% preallocate memory
d.ehdr = zeros(d.dim(1),d.dim(2),d.dim(3),d.nhdr,d.hdrlen);
d.ehdrste = zeros(d.dim(1),d.dim(2),d.dim(3),d.nhdr,d.hdrlen);
d.r2 = zeros(d.dim(1),d.dim(2),d.dim(3));

% turn off warnings to avoid divide by zero warning
warning('off','MATLAB:divideByZero');

% display string
disppercent(-inf,'(getr2) Calculating r2');
% cycle through images calculating the estimated hdr and r^2s of the 
% estimate.
%
% this following section has been optimized to run faster by
% eliminating one of the loops. Various different methods were
% tested eliminating all the loops and doing one big calculation
% which thrashed memory too much, or eliminating different
% dimensions and it was found that eliminating the first dimension
% was by far the faster by a factor of about 2-3. 
onesmatrix = ones(length(d.volumes),1);
for j = yvals
  disppercent(max((j-min(yvals))/yvaln,0.1));
  for k = slices
    % get the time series we are working on
    % this includes all the rows of one column from one slice
    % and all data points for each of these
    % thus the time series is a nxm matrix where each of the m columns
    % contains the n time points recording for that voxel
    timeseries = squeeze(d.data(:,j,k,d.volumes))';
    % subtract off column means
    colmeans = mean(timeseries,1);
    timeseries = timeseries - onesmatrix*colmeans;
    % convert to percent signal change
    timeseries = 100*timeseries./(onesmatrix*colmeans);
    % get hdr for the each voxel
    ehdr{j,k} = precalcmatrix*timeseries;
    % calculate error bars, first get sum-of-squares of residual
    % (in percent signal change)
    sumOfSquaresResidual = sum((timeseries-d.scm*ehdr{j,k}).^2);
    % now calculate the sum-of-squares of that error
    % and divide by the degrees of freedom (n-k where n
    % is the number of timepoints in the scan and k is 
    % the number of timepoints in all the estimated hdr)
    S2 = sumOfSquaresResidual/(length(d.volumes)-size(d.scm,2));
    % now distribute that error to each one of the points
    % in the hemodynamic response according to the inverse
    % of the covariance of the stimulus convolution matrix.
    ehdrste{j,k} = sqrt(diag(pinv(d.scm'*d.scm))*S2);
    % calculate variance accounted for by the estimated hdr
    r2{j,k} = (1-sumOfSquaresResidual./sum(timeseries.^2));
    correlation{j,k} = corrcoef(timeseries,(d.scm*ehdr{j,k}));
  end
end
disppercent(inf);

% reshape matrix. this also seems the fastest way to do things. we
% could have made a matrix in the above code and then reshaped here
% but the reallocs needed to continually add space to the matrix
% seems to be slower than the loops needed here to reconstruct
% the matrix from the {} arrays.
disppercent(-inf,'(getr2) Reshaping matrices');
for i = xvals
  disppercent((i-min(xvals))/xvaln);
  for j = yvals
    for k = slices
      % get the ehdr
      d.ehdr(i,j,k,1:d.nhdr,:) = reshape(squeeze(ehdr{j,k}(:,i)),[d.hdrlen d.nhdr])';
      % and the stderror of that
      d.ehdrste(i,j,k,1:d.nhdr,:) = reshape(squeeze(ehdrste{j,k}(:,i)),[d.hdrlen d.nhdr])';
      % now reshape r2 into a matrix
      d.r2(i,j,k) = r2{j,k}(i);
    end
  end
end

% display time took
disppercent(inf);

warning('on','MATLAB:divideByZero');
